"""Permutation correction after layout-elide transpilation.

When `transpile(..., optimization_level=3)` is run with `_layout` cleared,
Qiskit's elide-permutations pass may absorb terminal swaps into the layout, so
the emitted circuit's unitary differs from the reference by a basis permutation
P induced by a qubit permutation sigma. `fix_against_reference` detects sigma
from D = U_opt . U_ref^dagger (or its right-handed counterpart) and appends a
minimum bubble-sort SWAP network to undo it.
"""
import numpy as np
from qiskit import QuantumCircuit

from recognize_toffoli import _unitary


def _sigma_from_D(D, n):
    """If D is a basis-permutation matrix induced by qubit permutation sigma
    (qubit i -> sigma[i]), return sigma; else None."""
    idx = np.unravel_index(np.argmax(np.abs(D)), D.shape)
    if abs(D[idx]) < 0.5:
        return None
    ph = D[idx] / abs(D[idx])
    Dn = D / ph
    sigma = []
    for i in range(n):
        row = 1 << i
        col = int(np.argmax(np.abs(Dn[row])))
        if abs(Dn[row, col]) < 0.99 or bin(col).count("1") != 1:
            return None
        sigma.append(col.bit_length() - 1)
    if sorted(sigma) != list(range(n)):
        return None
    return sigma


def _swap_seq_for_sigma(sigma):
    """Bubble sigma to identity; the resulting swap sequence realizes sigma^-1."""
    arr = list(sigma)
    swaps = []
    n = len(arr)
    for i in range(n):
        if arr[i] != i:
            j = arr.index(i)
            swaps.append((j, i))
            arr[i], arr[j] = arr[j], arr[i]
    return swaps


def fix_against_reference(qc_opt: QuantumCircuit, qc_ref: QuantumCircuit) -> QuantumCircuit:
    """Append (or prepend) a SWAP network so qc_opt's unitary matches qc_ref's,
    handling both U_t = P . U_o (left perm: append) and U_t = U_o . P
    (right perm: prepend)."""
    n = qc_opt.num_qubits
    U_o = _unitary(qc_ref)
    U_t = _unitary(qc_opt)
    sigma_left = _sigma_from_D(U_t @ U_o.conj().T, n)
    sigma_right = _sigma_from_D(U_o.conj().T @ U_t, n)
    if sigma_left is not None:
        swaps = _swap_seq_for_sigma(sigma_left)
        out = qc_opt.copy()
        for a, b in swaps:
            out.swap(a, b)
        return out
    if sigma_right is not None:
        swaps = _swap_seq_for_sigma(sigma_right)
        out = qc_opt.copy_empty_like()
        for a, b in swaps:
            out.swap(a, b)
        out.compose(qc_opt, inplace=True)
        return out
    return qc_opt.copy()
