"""Rewrite single-qubit u(theta, phi, lambda) gates whose matrices match named
1-qubit Cliffords back into their named form, and provide a conservative
PassManager (`safe_pm`) that loops inverse cancellation, commutative
cancellation, and 1-qubit absorption.

Renaming a u3 as `h`, `s`, etc. does not change the gate count by itself, but
it enables Qiskit's name-aware CommutativeCancellation to recognize additional
commutation opportunities on the following peephole sweep.
"""
import numpy as np
from qiskit import QuantumCircuit
from qiskit.circuit.library import (
    CCXGate, CXGate, CZGate, HGate, IGate, SdgGate, SGate, SwapGate,
    SXdgGate, SXGate, TdgGate, TGate, XGate, YGate, ZGate,
)
from qiskit.transpiler import PassManager
from qiskit.transpiler.passes import (
    CommutativeCancellation, InverseCancellation, Optimize1qGatesDecomposition,
)

TOL = 1e-6

# 1-qubit Clifford / T library (matrices), checked up to global phase.
CLIFFORDS = {
    "id":   np.eye(2, dtype=complex),
    "h":    (1 / np.sqrt(2)) * np.array([[1, 1], [1, -1]], dtype=complex),
    "x":    np.array([[0, 1], [1, 0]], dtype=complex),
    "y":    np.array([[0, -1j], [1j, 0]], dtype=complex),
    "z":    np.array([[1, 0], [0, -1]], dtype=complex),
    "s":    np.array([[1, 0], [0, 1j]], dtype=complex),
    "sdg":  np.array([[1, 0], [0, -1j]], dtype=complex),
    "sx":   0.5 * np.array([[1 + 1j, 1 - 1j], [1 - 1j, 1 + 1j]], dtype=complex),
    "sxdg": 0.5 * np.array([[1 - 1j, 1 + 1j], [1 + 1j, 1 - 1j]], dtype=complex),
    "t":    np.array([[1, 0], [0, np.exp(1j * np.pi / 4)]], dtype=complex),
    "tdg":  np.array([[1, 0], [0, np.exp(-1j * np.pi / 4)]], dtype=complex),
}
CLIFFORD_GATES = {
    "id": IGate(), "h": HGate(), "x": XGate(), "y": YGate(), "z": ZGate(),
    "s": SGate(), "sdg": SdgGate(), "sx": SXGate(), "sxdg": SXdgGate(),
    "t": TGate(), "tdg": TdgGate(),
}


def equiv_up_to_phase(A, B, tol=TOL):
    idx = np.unravel_index(np.argmax(np.abs(A)), A.shape)
    if abs(B[idx]) < 1e-12:
        return False
    ph = A[idx] / B[idx]
    if abs(abs(ph) - 1) > tol:
        return False
    return np.max(np.abs(A - ph * B)) < tol


def match_named_1q(matrix):
    for name, ref in CLIFFORDS.items():
        if equiv_up_to_phase(matrix, ref):
            return name
    return None


def rewrite_1q(qc: QuantumCircuit):
    """Rename u3 gates that equal a named Clifford to that gate; drop identities."""
    new = QuantumCircuit(*qc.qregs, *qc.cregs)
    n_id = 0
    n_renamed = 0
    for ci in qc.data:
        op = ci.operation
        if op.num_qubits == 1 and op.num_clbits == 0:
            try:
                m = op.to_matrix()
            except Exception:
                m = None
            if m is not None:
                name = match_named_1q(m)
                if name == "id":
                    n_id += 1
                    continue
                if name is not None and name != op.name:
                    new.append(CLIFFORD_GATES[name], ci.qubits)
                    n_renamed += 1
                    continue
        new.append(ci)
    print(f"  1q rewrite: dropped {n_id} identities, renamed {n_renamed} to Cliffords")
    return new


def safe_pm(qc):
    """Four loops of unitary-preserving peephole: inverse cancellation,
    commutative cancellation, and 1-qubit absorption."""
    inv_pairs = [
        HGate(), XGate(), YGate(), ZGate(),
        SwapGate(), CXGate(), CZGate(), CCXGate(),
        (SGate(), SdgGate()),
        (TGate(), TdgGate()),
        (SXGate(), SXdgGate()),
    ]
    pm = PassManager()
    for _ in range(4):
        pm.append(InverseCancellation(inv_pairs))
        pm.append(CommutativeCancellation())
        pm.append(Optimize1qGatesDecomposition())
    return pm.run(qc)
