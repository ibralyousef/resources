"""End-to-end optimization pipeline for the COE 530 benchmark circuit.

The pipeline first replaces the four textbook 15-gate Toffoli decompositions
with atomic ccx gates, then iterates a peephole body to a fixed point:

  1. collapse_toffolis     : recognize the textbook 15-gate CCX decomposition
                             and replace each match with an atomic ccx.

  Per iteration:
    a. transpile(O3)       : Qiskit optimization_level=3 with basis
                             {cx, ccx, u} so ccx survives the synthesis stack.
    b. fix_against_reference : append a SWAP network to undo the qubit
                               permutation introduced by layout elision.
    c. collapse_toffolis   : re-collapse any Toffolis exposed by O3.
    d. safe_pm             : four loops of inverse cancellation, commutative
                             cancellation, and 1-qubit absorption.
    e. rewrite_1q          : rename u3 gates that equal a named Clifford
                             (H, X, Y, Z, S, S^dag, SX, SX^dag, T, T^dag)
                             so the next iteration's commutation rules can act.
    f. fix_against_reference : final permutation sanity check.

Writes the best circuit to benchmark_iterall.qasm.
"""
from pathlib import Path

from qiskit import qasm3, transpile

from recognize_toffoli import collapse_toffolis
from clifford_rewrite import rewrite_1q, safe_pm
from sliced_optimize import fix_against_reference

ROOT = Path(__file__).parent
SRC = ROOT / "benchmark_circuit.qasm"
DST = ROOT / "benchmark_iterall.qasm"
SKIP = {"barrier", "measure", "delay", "reset"}


def score_qc(qc):
    n = qc.num_qubits
    g = sum(1 for ci in qc.data if ci.operation.name not in SKIP)
    d = qc.depth(filter_function=lambda ci: ci.operation.name not in SKIP)
    return n, d, g, 10 * n + d + g


def one_pass(qc, qc_orig):
    """A single optimization round. The two strategies (Qiskit O3 with
    permutation correction, and the Clifford-rename + safe peephole loop)
    each yield a candidate; the lower-scoring one is returned."""
    # Strategy A: full Qiskit O3 with ccx-aware basis, then perm-fix and re-collapse.
    a = transpile(qc, basis_gates=["cx", "ccx", "u"], optimization_level=3)
    a._layout = None
    a = fix_against_reference(a, qc_orig)
    a = collapse_toffolis(a)
    sa = score_qc(a)[3]

    # Strategy B: peephole + Clifford rename + perm-fix + re-collapse.
    b = safe_pm(qc)
    b = rewrite_1q(b)
    b = fix_against_reference(b, qc_orig)
    b = collapse_toffolis(b)
    sb = score_qc(b)[3]

    return b if sb <= sa else a


def main():
    qc_orig = qasm3.load(str(SRC))
    print(f"baseline: {score_qc(qc_orig)}")

    qc = collapse_toffolis(qc_orig)
    print(f"after init toffoli: {score_qc(qc)}")

    best_score = score_qc(qc)[3]
    best_qc = qc
    prev = best_score
    for it in range(15):
        candidate = one_pass(best_qc, qc_orig)
        s = score_qc(candidate)[3]
        print(f"iter {it}: {score_qc(candidate)}")
        if s < best_score:
            best_score = s
            best_qc = candidate
        elif s == prev:
            print(f"  stalled at iter {it}")
            break
        else:
            best_qc = candidate
        prev = s

    print(f"\nFINAL best: {score_qc(best_qc)}")
    DST.write_text(qasm3.dumps(best_qc))
    print(f"wrote {DST}")


if __name__ == "__main__":
    main()
