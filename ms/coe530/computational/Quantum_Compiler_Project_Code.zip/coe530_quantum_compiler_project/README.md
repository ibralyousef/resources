# COE 530 Quantum Compiler Project — Submission

This directory contains the final compiled circuit and the pipeline that
produced it for the COE 530 Term Project. Starting from the 12-qubit baseline
`benchmark_circuit.qasm` (score 606), the pipeline produces
`benchmark_iterall.qasm` at **score 385** (12 qubits, depth 46, 219 gates),
a 36% reduction. The output is verified to be unitary-equivalent to the
baseline up to a global phase (residual ~1e-16).

## Files

| File | Purpose |
|------|---------|
| `iter_all.py`           | Entry point. Loads the baseline, runs the optimization pipeline, writes `benchmark_iterall.qasm`. |
| `recognize_toffoli.py`  | Slides a length-15 window through the gate list and replaces each textbook Nielsen-Chuang Toffoli decomposition with a single atomic `ccx`. |
| `clifford_rewrite.py`   | Renames `u(theta,phi,lambda)` gates that match named 1-qubit Cliffords (H, X, Y, Z, S, S^dag, SX, SX^dag, T, T^dag), and exposes `safe_pm`, a unitary-preserving peephole PassManager. |
| `sliced_optimize.py`    | `fix_against_reference`: detects the qubit permutation induced by Qiskit's elide-permutations pass and appends a minimum bubble-sort SWAP network to undo it. |
| `scoreboard.py`         | Course-provided scoring + unitary verification driver. |
| `benchmark_circuit.qasm`| Input: 12-qubit baseline circuit (score 606). |
| `benchmark_iterall.qasm`| Output: optimized circuit (score 385). |

## Reproduction

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# Produce benchmark_iterall.qasm from benchmark_circuit.qasm
python3 iter_all.py

# Verify against the baseline unitary
python3 scoreboard.py submit benchmark_iterall.qasm
```

Expected scoreboard output:

```
[submit] stats: {'num_qubits': 12, 'depth': 46, 'gate_count': 219, 'score': 385.0}
[submit] unitary verified (residual=1.91e-16)
[ACCEPT] new best: score=385.00  (was 606.00, delta=-221.00)
```

## Final score

| | Qubits | Depth | Gates | Score |
|-|-:|-:|-:|-:|
| Baseline  | 12 | 105 | 381 | 606 |
| Optimized | 12 |  46 | 219 | **385** |

## Dependencies

See `requirements.txt`:

- `qiskit==2.4.1`
- `qiskit-aer`
- `numpy`
