"""Replace the textbook 15-gate Toffoli decomposition with native ccx gates.

The matcher slides a length-15 window through the gate list and looks for the
canonical Nielsen-Chuang CCX decomposition

  H_t, CX_{b,t}, T_t^dag, CX_{a,t}, T_t, CX_{b,t}, T_t^dag, CX_{a,t},
  T_t, T_b, H_t, CX_{a,b}, T_a, T_b^dag, CX_{a,b}

Each match is replaced with a single CCXGate on (a, b, t).
"""
from qiskit import QuantumCircuit
from qiskit.circuit.library import CCXGate
from qiskit_aer import AerSimulator
import numpy as np


def gate_tuple(instr) -> tuple:
    """(name, qubit_indices) for a CircuitInstruction, ignoring classical bits."""
    return instr.operation.name, tuple(instr.qubits)


def matches_toffoli(window) -> tuple | None:
    """Return (a, b, t) if window of 15 instructions is a textbook Toffoli decomp."""
    if len(window) != 15:
        return None
    names = [w.operation.name for w in window]
    expected = ["h", "cx", "tdg", "cx", "t", "cx", "tdg", "cx",
                "t", "t", "h", "cx", "t", "tdg", "cx"]
    if names != expected:
        return None

    t_q = window[0].qubits[0]
    if window[10].qubits[0] != t_q:
        return None
    if window[2].qubits[0] != t_q:
        return None
    if window[4].qubits[0] != t_q:
        return None
    if window[6].qubits[0] != t_q:
        return None
    if window[9].qubits[0] != t_q:
        return None
    if window[1].qubits[1] != t_q or window[5].qubits[1] != t_q:
        return None
    if window[3].qubits[1] != t_q or window[7].qubits[1] != t_q:
        return None
    b_q = window[1].qubits[0]
    a_q = window[3].qubits[0]
    if window[5].qubits[0] != b_q or window[7].qubits[0] != a_q:
        return None
    if window[11].qubits != (a_q, b_q) or window[14].qubits != (a_q, b_q):
        return None
    if window[8].qubits[0] != b_q:
        return None
    if window[12].qubits[0] != a_q:
        return None
    if window[13].qubits[0] != b_q:
        return None
    return a_q, b_q, t_q


def collapse_toffolis(qc: QuantumCircuit) -> QuantumCircuit:
    out = QuantumCircuit(*qc.qregs, *qc.cregs)
    data = list(qc.data)
    i = 0
    n_replaced = 0
    while i < len(data):
        match = matches_toffoli(data[i:i + 15])
        if match:
            a, b, t = match
            out.append(CCXGate(), [a, b, t])
            i += 15
            n_replaced += 1
        else:
            out.append(data[i])
            i += 1
    print(f"  replaced {n_replaced} Toffoli decompositions with ccx")
    return out


def _unitary(qc):
    q = qc.copy()
    q.save_unitary()
    return np.asarray(AerSimulator(method="unitary").run(q).result().get_unitary())
