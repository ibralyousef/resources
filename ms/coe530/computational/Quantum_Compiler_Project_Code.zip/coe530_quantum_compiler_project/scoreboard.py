"""Compilation scoreboard.

Score = 10 * num_qubits + depth + gate_count   (lower is better)

A submitted circuit is accepted only if its unitary matches the baseline
(`benchmark_circuit.qasm`) up to a global phase.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
import time
from pathlib import Path

import numpy as np
from qiskit import QuantumCircuit
from qiskit.qasm2 import loads as qasm2_loads
from qiskit.qasm3 import loads as qasm3_loads
from qiskit_aer import AerSimulator

# Gate names excluded from depth and gate_count, matching the reference scoreboard
# (mfelemban/QCompiler-scoreboard).
_SKIP = {"barrier", "measure", "delay", "reset"}
# Weights for Score = w1*Qubits + w2*Depth + w3*Gates
W1, W2, W3 = 10.0, 1.0, 1.0

ROOT = Path(__file__).parent
BASELINE_QASM = ROOT / "benchmark_circuit.qasm"
STATE_FILE = ROOT / "scoreboard.json"
CACHE_DIR = ROOT / ".cache"
BASELINE_U_FILE = CACHE_DIR / "baseline_unitary.npy"
BEST_QASM = ROOT / "best.qasm"

PHASE_TOL = 1e-8


def file_sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def load_circuit(p: Path) -> QuantumCircuit:
    text = p.read_text()
    errors = []
    for name, fn in (("QASM 3", qasm3_loads), ("QASM 2", qasm2_loads)):
        try:
            return fn(text)
        except Exception as exc:
            errors.append(f"{name}: {exc}")
    raise ValueError(f"Could not parse {p.name}.\n" + "\n".join(errors))


def compute_unitary(qc: QuantumCircuit) -> np.ndarray:
    # Recursively decompose user-defined gates so Aer sees only known instructions.
    # The reference scoreboard uses qiskit's Operator() which does the same; this is
    # purely for unitary computation and does not affect the gate count we score.
    work = qc
    for _ in range(8):
        names = {ci.operation.name for ci in work.data}
        unknown = names - {
            "u", "u1", "u2", "u3", "p", "r", "id", "x", "y", "z", "h", "s", "sdg",
            "t", "tdg", "sx", "sxdg", "rx", "ry", "rz",
            "cx", "cy", "cz", "ch", "cp", "cu", "cu1", "cu3", "swap", "iswap",
            "ccx", "ccz", "cswap", "rxx", "ryy", "rzz", "rzx",
        }
        if not unknown:
            break
        work = work.decompose()
    work = work.copy()
    work.save_unitary()
    result = AerSimulator(method="unitary").run(work).result()
    return np.asarray(result.get_unitary())


def score(qc: QuantumCircuit) -> tuple[float, dict]:
    n = qc.num_qubits
    g = sum(1 for ci in qc.data if ci.operation.name not in _SKIP)
    d = qc.depth(filter_function=lambda ci: ci.operation.name not in _SKIP)
    s = W1 * n + W2 * d + W3 * g
    return s, {"num_qubits": n, "depth": d, "gate_count": g, "score": s}


def unitary_equiv(u1: np.ndarray, u2: np.ndarray, tol: float = PHASE_TOL) -> tuple[bool, float]:
    """Check U1 == e^{i phi} U2. Returns (ok, max_residual)."""
    if u1.shape != u2.shape:
        return False, float("inf")
    idx = np.unravel_index(np.argmax(np.abs(u1)), u1.shape)
    if abs(u2[idx]) < 1e-12:
        return False, float("inf")
    phase = u1[idx] / u2[idx]
    phase /= abs(phase)
    residual = float(np.max(np.abs(u1 - phase * u2)))
    return residual < tol, residual


def load_state() -> dict:
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text())
    return {}


def save_state(state: dict) -> None:
    STATE_FILE.write_text(json.dumps(state, indent=2))


def ensure_baseline(state: dict, force: bool = False) -> np.ndarray:
    CACHE_DIR.mkdir(exist_ok=True)
    h = file_sha256(BASELINE_QASM)
    cached_h = state.get("baseline_hash")
    if not force and cached_h == h and BASELINE_U_FILE.exists():
        return np.load(BASELINE_U_FILE)

    print(f"[baseline] computing unitary for {BASELINE_QASM.name} ...")
    qc = load_circuit(BASELINE_QASM)
    t0 = time.perf_counter()
    u = compute_unitary(qc)
    dt = time.perf_counter() - t0
    s, stats = score(qc)
    print(f"[baseline] done in {dt:.2f}s   {stats}")

    np.save(BASELINE_U_FILE, u)
    state["baseline_file"] = BASELINE_QASM.name
    state["baseline_hash"] = h
    state["baseline_stats"] = stats
    state.setdefault("history", [])
    save_state(state)
    return u


def cmd_init(args) -> int:
    state = load_state()
    ensure_baseline(state, force=args.force)
    print(f"[init] state: {STATE_FILE.name}")
    return 0


def cmd_show(args) -> int:
    state = load_state()
    if not state:
        print("no state yet — run `init` or `submit` first")
        return 0
    base = state.get("baseline_stats", {})
    best = state.get("best", None)
    print(f"baseline ({state.get('baseline_file')}):  {base}")
    if best:
        print(f"best     ({best.get('file')}):  "
              f"{ {k: best[k] for k in ('num_qubits','depth','gate_count','score')} }")
        print(f"  improvement vs baseline: {base['score'] - best['score']}")
    else:
        print("best:    <none accepted yet>")
    hist = state.get("history", [])
    if hist:
        print(f"history: {len(hist)} submission(s)")
        for entry in hist[-10:]:
            mark = "OK " if entry["accepted"] else "REJ"
            sc = entry.get("score")
            sc_str = f"{sc:.2f}" if isinstance(sc, (int, float)) else "-"
            print(f"  [{mark}] {entry['file']:40s} score={sc_str:>8}  {entry['reason']}")
    return 0


def cmd_submit(args) -> int:
    candidate_path = Path(args.circuit).resolve()
    if not candidate_path.exists():
        print(f"error: {candidate_path} not found")
        return 2

    state = load_state()
    u_base = ensure_baseline(state)

    print(f"[submit] loading {candidate_path.name}")
    qc = load_circuit(candidate_path)

    bad = [ci.operation.name for ci in qc.data if ci.operation.name in ("measure", "reset")]
    if bad:
        print(f"[REJECT] candidate contains '{bad[0]}' — measurements/resets break unitary equivalence")
        entry = {
            "file": candidate_path.name,
            "path": str(candidate_path),
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "accepted": False,
            "reason": f"contains '{bad[0]}'",
        }
        state.setdefault("history", []).append(entry)
        save_state(state)
        return 1

    cand_score, stats = score(qc)
    print(f"[submit] stats: {stats}")

    print(f"[submit] computing candidate unitary ...")
    t0 = time.perf_counter()
    u_cand = compute_unitary(qc)
    dt = time.perf_counter() - t0
    print(f"[submit] unitary in {dt:.2f}s   shape={u_cand.shape}")

    ok, residual = unitary_equiv(u_cand, u_base)
    history_entry = {
        "file": candidate_path.name,
        "path": str(candidate_path),
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        **stats,
        "residual": residual,
    }

    if not ok:
        history_entry.update(accepted=False, reason=f"unitary mismatch (residual={residual:.2e})")
        state.setdefault("history", []).append(history_entry)
        save_state(state)
        print(f"[REJECT] unitary differs from baseline (max residual={residual:.2e}, tol={PHASE_TOL:.0e})")
        return 1

    print(f"[submit] unitary verified (residual={residual:.2e})")

    best = state.get("best")
    if best is not None and cand_score >= best["score"]:
        history_entry.update(
            accepted=False,
            reason=f"score {cand_score} not better than current best {best['score']}",
        )
        state.setdefault("history", []).append(history_entry)
        save_state(state)
        print(f"[NO-IMP] score {cand_score:.2f} does not beat best {best['score']:.2f}")
        return 0

    shutil.copyfile(candidate_path, BEST_QASM)
    history_entry.update(accepted=True, reason="new best")
    state["best"] = {**stats, "file": BEST_QASM.name, "source": candidate_path.name,
                     "residual": residual, "timestamp": history_entry["timestamp"]}
    state.setdefault("history", []).append(history_entry)
    save_state(state)

    prev = best["score"] if best else state["baseline_stats"]["score"]
    print(f"[ACCEPT] new best: score={cand_score:.2f}  (was {prev:.2f}, delta={cand_score - prev:+.2f})")
    print(f"         saved -> {BEST_QASM.name}")
    return 0


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="cmd", required=True)

    p_init = sub.add_parser("init", help="compute baseline unitary and initialize state")
    p_init.add_argument("--force", action="store_true", help="recompute baseline even if cached")
    p_init.set_defaults(func=cmd_init)

    p_show = sub.add_parser("show", help="display current baseline / best / history")
    p_show.set_defaults(func=cmd_show)

    p_sub = sub.add_parser("submit", help="submit a candidate compiled circuit (.qasm)")
    p_sub.add_argument("circuit", help="path to candidate OPENQASM 3.0 file")
    p_sub.set_defaults(func=cmd_submit)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
